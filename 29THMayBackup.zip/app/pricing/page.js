import React from 'react';
import styles from '@/Styles/pricing.module.css';

const page = () => {
  return (
    <div className={styles.container}>
      <div></div>
      <div>Choose your plan</div>
      <div></div>
    </div>
  )
}

export default page
