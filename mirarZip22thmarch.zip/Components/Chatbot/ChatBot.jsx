"use client";
import React, { useEffect, useRef, useState } from "react";
import styles from "@/Styles/Chat.module.css";
import Language from "@/public/Chat/language.png";
import CloseCircle from "@/public/Chat/CloseCircle.png";
import Mic from "@/public/Chat/Mic.png";
import Refresh from "@/public/Chat/Refresh.png";
import RecordButton from "@/public/Chat/Record.png";
import Pin from "@/public/Chat/Pin.png";
import sent from "@/public/Chat/sent.webp";
import Image from "next/image";
import API from "@/app/api";

const Chatbot = () => {
  const languageRef=useRef();
  const [newMessage, setNewMessage] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [influencerDetails, setInfluencerDetails] = useState({});
  const [languages,setLanguages]=useState([]);

  const authToken =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InhvdG9kaXd1QHBlbGFnaXVzLm5ldCIsInVzZXJJZCI6NTcsIl9pZCI6IjY1ZmQ4MjE0MjY2NThjOGUxOGRjM2Y4YiIsImFjY291bnRUeXBlIjoiVVNFUiIsImlhdCI6MTcxMTExMjc4OCwiZXhwIjoxNzExNDU4Mzg4fQ.WXggCjM6j2F33-5bAm5VZWjpBFwyG8DBHQlAIfraWyQ";
  const influencer = "65f013ab3aae4b4e469418f2";
  const handleMicButtonClick = () => {
    setIsChatOpen(false);
  };
  const handleCancelButtonClick = () => {
    setIsChatOpen(true);
  };

  const handleChange = (e) => {
    setNewMessage(e.target.value);
  };

  const handleSubmitText = async (e) => {
    if (chatMessages.length >= 5) {
      window.alert("No more free trials");
      e.preventDefault();
      setNewMessage("");
    } else {
      e.preventDefault();
      const message = newMessage;
      setNewMessage("");

      const message_object = {
        question: message,
        answer: "...",
      };

      setChatMessages([...chatMessages, message_object]);

      console.log("Message is: ", message);
      //Construct the request body

      const formData = new FormData();
      formData.set("influencerId", influencer);
      formData.set("questions", message);

      try {
        const response = await API.postAPICalling(
          "/users/askQuestionByLanguageNew",
          formData,
          authToken
        );
        setChatMessages([...chatMessages, response]);
        console.log(response);
      } catch (error) {
        console.log("Error : ", error);
      }
    }
  };

  const handleGetLanguages = async () => {
    try {
      const response = await API.getAPICalling(
        "/users/getAllLanguage",
        authToken
      );
      setLanguages(response);
      console.log(response);
    } catch (error) {
      console.log("Error: ", error);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await API.getAPICalling(
          `/users/getChatMessagesNew?influencerId=${influencer}&page=1&limit=20`,
          authToken
        );
        setInfluencerDetails(response.influencerDetails);
        setChatMessages(response.data);
        console.log(response);
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();
  }, []);

  return (
    <>
      {isChatOpen ? (
        <div className={styles.chatbot_container}>
          <div className={styles.top_container}>
            <div className={styles.left_items}>
              <h1> &lt; </h1>
              <div>
                {/* <Image
                  src={influencerDetails && influencerDetails.avatarImageUrl}
                  className={styles.influencerImage}
                  width={30}
                  height={20}
                /> */}
                PC
              </div>
              <div className="font-bold">
                {influencerDetails && influencerDetails.userName}
              </div>
            </div>
            <button onClick={handleGetLanguages}>
              <div className={styles.language_image}>
                <Image src={Language} alt="Language selector button image" />
              </div>
            </button>
          </div>
          <div className={styles.main_container}>
            <div className={styles.text_container}>
              {chatMessages &&
                chatMessages.map((message, index) => (
                  <>
                    <div className={`chat-message user`}>
                      {message.question}
                    </div>
                    <div className={`chat-message bot`}>{message.answer}</div>
                  </>
                ))}
            </div>
          </div>
          <form
            onSubmit={
              newMessage.trim("").length
                ? handleSubmitText
                : handleMicButtonClick
            }
          >
            <div className={styles.bottom_container}>
              <div className={styles.pin_image}>
                <Image src={Pin} width={30} height={30} />
              </div>
              <div className={styles.text_input}>
                <input
                  type="text"
                  value={newMessage}
                  name="newMessage"
                  onChange={handleChange}
                  placeholder="Message..."
                />
              </div>
              <div className={styles.internet_image}>
                <button type="submit">
                  <Image
                    src={newMessage.trim("").length ? sent : RecordButton}
                    width={50}
                    height={50}
                  />
                </button>
              </div>
            </div>
          </form>
          <div ref={languageRef} className={styles.language_box}>
            <h1>Choose Your Language</h1>
            {languages.map((language)=>(
              <div>
                {language.language}
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className={styles.audio_input_container}>
          <div className={styles.visualizer}></div>
          <div className={styles.control_box}>
            <p>0:10</p>
            <div className={styles.controller_button_container}>
              <div className={styles.refresh}>
                <Image src={Refresh} alt="refresh image" />
              </div>
              <div className={styles.mic_container}>
                <div className={styles.mic}>
                  <Image src={Mic} alt="Mic image" />
                </div>
              </div>
              <div onClick={handleCancelButtonClick} className={styles.cross}>
                <Image src={CloseCircle} alt="Cross image" />
              </div>
            </div>
            <h1>Tap to stop recording</h1>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
