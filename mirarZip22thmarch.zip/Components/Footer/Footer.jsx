import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
      <span>Copyright @ 2024 MIRAR AI Inc. All Rights Reserved.</span>
    </div>
  )
}

export default Footer
