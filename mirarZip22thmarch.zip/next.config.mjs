/** @type {import('next').NextConfig} */
const nextConfig = {
    images:{
        domains:['api.mirar.ai'],
    },
};

export default nextConfig;
